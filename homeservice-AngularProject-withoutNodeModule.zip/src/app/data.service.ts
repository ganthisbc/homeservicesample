import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  public servicelist = [
    { id: 1, title:'Cleaning Services', list: ['Home Cleaning Services', 'Sofa Cleaning Services','Kitchen Cleaning Services', 'Bathroom Cleaning Services']},
    { id: 2, title: 'Appliance Repair', list: ['AC Service and Repair', 'Refrigerator Repair', 'Washing Machine Service and Repair']}];
  
  public selectedServiceId = 0 ;
  public selectedService = "";
  constructor() { 

  }
}
