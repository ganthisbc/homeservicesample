import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/data.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-service-list',
  templateUrl: './service-list.component.html',
  styleUrls: ['./service-list.component.scss']
})
export class ServiceListComponent implements OnInit {
  public serviceDetails = [];  
  public servicedatalist = [];
  public selectedServiceId = 0;
  public serviceTiming: string = "";
  public selectedService: string = "";
  public userName: string = "";

  constructor(public DS : DataService, public _router : Router ) { 
    if(this.DS.selectedServiceId > 0){
      this.selectedService = this.DS.selectedService;
    }         
    
  }
  onService(id: number, servicetype: string ){ 
    this.selectedService = servicetype;
    this.selectedServiceId = id;   
    this.servicedatalist =  this.serviceDetails[this.selectedServiceId-1].list;   
  }
  updateservicedatalist(){   
    this.servicedatalist =  this.serviceDetails[this.selectedServiceId-1].list;
  }
  onSubmit(){ 
    let validTxt = ""  ;
    if(this.userName == ""){
      validTxt += "Please Enter Your Name \n";
    }
    if(this.serviceTiming == ""){
      validTxt += "Please Enter Timing Slot \n";
    }    
    if(validTxt != "")
    {
      alert(validTxt);
    }      
    else{
      alert("service Registered Details: \n"+"UserName :"+this.userName+"\n Service Category :"+ this.serviceDetails[this.selectedServiceId-1].title + "\n Service Type :"+ this.selectedService +"\n Service Timing Slot :"+this.serviceTiming);
    }
  }
  ngOnInit() {
    this.serviceDetails = this.DS.servicelist;

  }

}
