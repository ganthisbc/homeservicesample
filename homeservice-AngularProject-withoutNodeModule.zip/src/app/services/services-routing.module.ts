import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { HomeComponent } from './home/home.component';
import {ServiceListComponent} from './service-list/service-list.component';

const serviceroutes: Routes = [
  { 
    path: 'home',
    component: HomeComponent
  },
  { 
    path: 'services',
    component: ServiceListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(serviceroutes)],
  exports: [RouterModule]
})
export class ServicesRoutingModule { }
