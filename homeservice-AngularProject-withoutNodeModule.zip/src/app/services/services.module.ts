import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { ServicesRoutingModule } from './services-routing.module';
import { ServiceListComponent } from './service-list/service-list.component';
import { HomeComponent } from './home/home.component';

@NgModule({
  declarations: [ServiceListComponent, HomeComponent],
  imports: [
    CommonModule,
    FormsModule,
    ServicesRoutingModule
  ]
})
export class ServicesModule { }
